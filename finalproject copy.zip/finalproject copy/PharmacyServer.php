<?php
session_start();
require_once 'PharmacyDatabase.php';

class PharmacyPortal {
    // ...

    private $db;

    public function __construct() {
        $this->db = new PharmacyDatabase();
    }

    public function handleRequest() {
        $action = $_GET['action'] ?? 'home';

        switch ($action) {
            case 'addPrescription':
                $this->addPrescription();
                break;
            case 'viewPrescriptions':
                $this->viewPrescriptions();
                break;
            case 'viewInventory':
                $this->viewInventory();
                break;
            case 'addUser':
                $this->addUser();
                break;
            case 'addMedication':
                $this->addMedication();
                break;
                
            default:
                $this->home();
        }
    }

    private function home() {
        include 'templates/home.php';
    }

    private function addPrescription() {
       

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
          
            $patientUserName = $_POST['patient_username'];
            $medicationId= $_POST['medication_id'];
            $dosageInstructions = $_POST['dosage_instructions'];
            $quantity = $_POST['quantity'];


    







            $this->db->addPrescription($patientUserName, $medicationId, $dosageInstructions, $quantity);
            header("Location: PharmacyServer.php?action=viewPrescriptions&message=Prescription+Added");
exit;

        } else {
            include 'templates/addPrescription.php';
        }
    }

    private function viewPrescriptions() {
     
     $userId = $_SESSION['userId'] ?? null;
     $prescriptions = $this->db->getPrescriptionsByAccess($userId);

        if (file_exists('templates/viewPrescriptions.php')) {
            include 'templates/viewPrescriptions.php';
        } else {
            echo "TEMPLATE FILE NOT FOUND.";
        }
        
    }

// scope below is meant to add a new medication to my database //
    private function addMedication() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['medication_name'];
            $dosage = $_POST['dosage'];
            $manufacturer = $_POST['manufacturer'];
    
            $this->db->addMedication($name, $dosage, $manufacturer);
            header("Location: PharmacyServer.php?action=home");
            exit;
        } else {
            include 'templates/addMedication.php';
        }
    }
    
// scope below is meant to add a new user to my database //
    private function addUser() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $contact = $_POST['contact'];
            $usertype = $_POST['usertype'];
    
            $this->db->addUser($username, $contact, $usertype);
            header("Location: PharmacyServer.php?action=home");
            exit;
        } else {
            include 'templates/addUser.php';
        }
    }
    





}

$portal = new PharmacyPortal();
$portal->handleRequest();
