<?php
class PharmacyDatabase {
    private $host = "localhost";
    private $port = "3306";
    private $database = "pharmacy_portal_db";
    private $user = "root";
    private $password = "";
    private $connection;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        $this->connection = new mysqli($this->host, $this->user, $this->password, $this->database, $this->port);
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }
        echo "Successfully connected to the database";
    }


// Section below is meant to identiy who is logged in // 

    public function verifyLogin($userName, $userId) {
        $stmt = $this->connection->prepare("SELECT * FROM Users WHERE userName = ? AND userId = ?");
        $stmt->bind_param("si", $userName, $userId); // "si" is for string and integer
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Return user data if login is successful
        } else {
            return null; // Return null if no matching user is found
        }
    }
// above was added so you may be able to delete 


    public function addPrescription($patientUserName, $medicationId, $dosageInstructions, $quantity)  {
        $stmt = $this->connection->prepare(
            "SELECT userId FROM Users WHERE userName = ? AND userType = 'patient'"
        );
        $stmt->bind_param("s", $patientUserName);
        $stmt->execute();
        $stmt->bind_result($patientId);
        $stmt->fetch();
        $stmt->close();
        
        if ($patientId){
            $stmt = $this->connection->prepare(
                "INSERT INTO prescriptions (userId, medicationId, dosageInstructions, quantity) VALUES (?, ?, ?, ?)"
            );
            $stmt->bind_param("iisi", $patientId, $medicationId, $dosageInstructions, $quantity);
            $stmt->execute();
            $stmt->close();
            echo "Prescription added successfully";
        }else{
            echo "failed to add prescription";
        }
    }

    public function getAllPrescriptions() {
        $result = $this->connection->query("SELECT * FROM  prescriptions join medications on prescriptions.medicationId= medications.medicationId");


// added now 
if (!$result) {
    die("SQL Error: " . $this->connection->error);
}
//added now 

return $result->fetch_all(MYSQLI_ASSOC);

    }

// this section in the verification section that allows patients to ONLY view their info based on logged in user Id or allows pharmacist to view all patients prescriptions

public function getPrescriptionsByAccess($userId) {
    // First, check user type
    $stmt = $this->connection->prepare("SELECT userType FROM Users WHERE userId = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($userType);
    $stmt->fetch();
    $stmt->close();

   

    if ($userType === 'pharmacist') {
        $result = $this->connection->query(
            "SELECT * FROM prescriptions 
             JOIN medications ON prescriptions.medicationId = medications.medicationId"
        );
    } else {
        $stmt = $this->connection->prepare(
            "SELECT * FROM prescriptions 
             JOIN medications ON prescriptions.medicationId = medications.medicationId 
             WHERE prescriptions.userId = ?"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
    }

    return $result->fetch_all(MYSQLI_ASSOC);
}


    
    // this is the section that allows the Doctor to add a new prescription to the datatbase 
        public function addMedication($medicationName, $dosage, $manufacturer) {
            $stmt = $this->connection->prepare(
                "INSERT INTO Medications (medicationName, dosage, manufacturer) VALUES (?, ?, ?)"
            );
            $stmt->bind_param("sss", $medicationName, $dosage, $manufacturer);
            
            if ($stmt->execute()) {
                echo "Medication added successfully";
            } else {
                echo "Failed to add medication: " . $stmt->error;
            }
        
            $stmt->close();
        }
        


    public function addUser($userName, $contactInfo, $userType) {
     //Write Code here
    }

    //Add Other needed functions here
}
?>
