<html>


<head>
<title> Pharmacy Portal</title>



<link rel="stylesheet" href="css/style.css">
</head>
<body>


    <h1>Pharmacy Portal</h1>
    <nav>
    <a href="PharmacyServer.php?action=addPrescription" class="nav-link">Add Prescription</a>
    <a href="PharmacyServer.php?action=viewPrescriptions" class="nav-link">View Prescriptions</a>
    <a href="PharmacyServer.php?action=addMedication" class="nav-link">Add Medication</a>
    <a href="PharmacyServer.php?action=addUser" class="nav-link">Add User</a>
    </nav>
    <br> 

    <a href="exit.php" class="nav-link" style="border-color: red; color: red;">Logout</a>

</body>
</html>


