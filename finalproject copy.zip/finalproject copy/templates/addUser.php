<html>
<head>
    <title>Add User</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h1>Add New User</h1>

    <form method="POST" action="PharmacyServer.php?action=addUser">
        <label>User Name:</label><br>
        <input type="text" name="username" required><br><br>

        <label>Contact Info:</label><br>
        <input type="text" name="contact" required><br><br>

        <label>User Type:</label><br>
        <select name="usertype" required>
            <option value="">Select Type</option>
            <option value="patient">Patient</option>
            <option value="pharmacist">Pharmacist</option>
        </select><br><br>

        <button type="submit" class="nav-link">Add User</button>
    </form>

    <br>
    <a href="PharmacyServer.php?action=home" class="nav-link">Back to Home</a>
</body>
</html>
