<html>
<head>
    <title>Add Medication</title>
    <style>
        label {
            display: inline-block;
            width: 200px; /* Align labels to keep organization  */
            margin-bottom: 10px;
         }
    </style>
</head>
<body>

    <h1>Add Medication</h1>
    
    <form method="POST" action="PharmacyServer.php?action=addMedication">
        <label for="medication_name">Medication Name:</label>
        <input type="text" id="medication_name" name="medication_name" required>
        <br>

        <label for="dosage">Dosage:</label>
        <input type="text" id="dosage" name="dosage" required>
        <br>

        <label for="manufacturer">Manufacturer:</label>
        <input type="text" id="manufacturer" name="manufacturer">
        <br>

        <button type="submit">Add Medication</button>
    </form>
    <br>
    <a href="PharmacyServer.php?action=home" class="nav-link">Back to Home</a>

</body>
</html>
