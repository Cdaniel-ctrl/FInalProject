<?php
session_start(); // < This will be used to see who is logged in for security purposes //
require_once 'PharmacyDatabase.php';
$db = new PharmacyDatabase();


// below request inputs so it can verify with my db regarding existing users and proper credectials //
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $username = $_POST['username'];
    $userId = $_POST['userId'];

    // Verify login with the database
    $user = $db->verifyLogin($username, $userId);

    if ($user) {
        $_SESSION['userId'] = $user['userId']; // Save users id to determine login 
        header("Location: PharmacyServer.php?action=home");
        exit;
    }
     else {
        //  show an error message if unsucessful login
        $error_message = "Invalid username or userId. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>

    <?php if (isset($error_message)): ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br><br>

        <label for="userId">User ID:</label>
        <input type="text" name="userId" id="userId" required><br><br>

        <button type="submit">Login</button>
    </form>
</body>
</html>
